module.exports = {
    entry: './src/init.js'
};